var express = require("express");
var app = express();
var jade = require('jade');
app.use(express.logger());
app.use(express.bodyParser());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.use(express.static(__dirname + '/public'));
app.use(app.router);

var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://highscores:comp20@dharma.mongohq.com:10058/highscores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});


app.get('/',function(req,res){
  var scores = [];
  var done = false;
  db.collection('highscores',function(err,collection){
    collection.find({}, function(err, cursor) {             
      cursor.each(function(err, entry) {
        if(entry != null) {
          scores.push(entry);
        }else if(done == false){
          done = true;
          res.set('Content-Type', 'text/html');
          jade.renderFile('views/index.jade', {"games":scores} ,function(err,html){
              res.send(html);
          });
        }
      });    
    }); 
  });
});



app.get('/highscores.json', function(req, res) {
  var scores = [];
  var done = false;
  db.collection('highscores',function(err,collection){
    collection.find({"game_title":req.query.game_title},{'sort':[['score', -1]],'limit':10}, function(err, cursor) {             
      cursor.each(function(err, entry) {
        if(entry != null) {
          scores.push(entry);
        }else if(done == false){
          done = true;
          res.set('Content-Type', 'text/json');
          res.send(scores);
        }
      });
    });    
  });
});

app.get('/usersearch', function(req, res) {
  jade.renderFile('views/usersearch.jade',function(err,html){
    res.send(html);
  });
});

app.post('/usersearch', function(req, res) {
  var user = req.body.username;
  var scores = [];
  var done = false;
  db.collection('highscores',function(err,collection){
    collection.find({"username":user},{'sort':[['score', -1]]}, function(err, cursor) {             
      cursor.each(function(err, entry) {
        if(entry != null) {
          scores.push(entry);
        }else if(done == false){
          done = true;
          res.set('Content-Type', 'text/json');
            jade.renderFile('views/user.jade',{"username":user,"games":scores}, function(err,html){
              res.set('Content-Type', 'text/html');
              res.send(html);
            });
        }
      });
    });    
  });

});

app.post('/submit.json', function(req, res){
  data = req.body;
  data.score = parseInt(data.score)
  data.created_at = new Date();
  db.collection('highscores',function(err,collection){
    collection.insert([data]);
  });
  res.send(data);    // echo the result back
});


var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});
